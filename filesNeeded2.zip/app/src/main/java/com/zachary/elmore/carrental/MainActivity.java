package com.zachary.elmore.carrental;

// Zachary Elmore
// 3/26/2017

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    Integer[] Cars = {R.drawable.car1, R.drawable.car2, R.drawable.car3, R.drawable.car4,R.drawable.car5,R.drawable.car6};
    ImageView pic;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GridView grid = (GridView)findViewById(R.id.gridView);
        final ImageView pic = (ImageView) findViewById(R.id.imgLarge);
        grid.setAdapter(new ImageAdapter(this));


        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String carString = new String();

                pic.setImageResource(Cars[position]);

                if(Cars[position] == Cars[0]){
                    carString = "Chevy Camaro: $700 per week";
                }
                else if(Cars[position] == Cars[1]){
                    carString = "Ford Mustang: $750 per week";
                }
                else if(Cars[position] == Cars[2]){
                    carString = "Dodge Challenger: $600 per week";
                }
                else if(Cars[position] == Cars[3]){
                    carString = "Dodge Charger: $700 per week";
                }
                else if(Cars[position] == Cars[4]){
                    carString = "Smart-Car: $100 per week";
                }
                else if(Cars[position] == Cars[5]){
                    carString = "Renegade Jeep: $500 per week";
                }

                Toast.makeText(getBaseContext(), carString, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public class ImageAdapter extends BaseAdapter{
        private Context context;
        public ImageAdapter(Context c) {context=c;}

        @Override
        public int getCount() {return Cars.length;}

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            pic = new ImageView(context);
            pic.setImageResource(Cars[position]);
            pic.setScaleType(ImageView.ScaleType.FIT_XY);
            pic.setLayoutParams(new GridView.LayoutParams(330,300));
            return pic;
        }
    }
}